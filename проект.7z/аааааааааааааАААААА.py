import pygame
import os
import random
import sys

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
PURPLE = (255, 0, 255)
pygame.init()
screen = pygame.display.set_mode([800, 600])


def load_image(name, color_key=None):
    fullname = os.path.join('data1', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


player_image = load_image('cat.png')
coin_image = load_image('coins.png')
enemy_image = load_image('dog.jpg')


class Play(pygame.sprite.Sprite):
    def __init__(self, group, size):
        super().__init__(group)
        self.width = size[0]
        self.height = 50
        self.image = load_image("10.jpg")
        self.rect = self.image.get_rect()
        self.rect.center = (0, 400)
        self.step = 30

    def update(self, *args):
        if self.rect.left < 650:
            self.rect.left += self.step


def terminate():
    pygame.quit()
    sys.exit()


def main():
    size = 800, 600
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption('Maze')
    fon = pygame.transform.scale(load_image('fone.jpg'), (size[0], size[1]))
    screen.blit(fon, (0, 0))
    all_sprites = pygame.sprite.Group()
    Play(all_sprites, size)
    fps = 10
    clock = pygame.time.Clock()
    mp = pygame.mouse.get_pos()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                return

        fon = pygame.transform.scale(load_image('fone.jpg'), (size[0], size[1]))
        screen.blit(fon, (0, 0))
        all_sprites.draw(screen)
        all_sprites.update()
        clock.tick(fps)
        pygame.display.flip()

    pygame.quit()


if __name__ == '__main__':
    main()


class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, color):

        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill(color)

        self.rect = self.image.get_rect()
        self.rect.y = y
        self.rect.x = x


class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.image = coin_image
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.image = enemy_image
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.start = x
        self.stop = x + random.randint(180, 240)
        self.direction = -1

    def update(self):
        if self.rect.x >= self.stop:
            self.rect.x = self.stop
            self.direction = -1

        if self.rect.x <= self.start:
            self.rect.x = self.start
            self.direction = 1
        self.rect.x += self.direction * 2


class Player(pygame.sprite.Sprite):
    change_x = 0
    change_y = 0

    def __init__(self, x, y):
        super().__init__()

        self.image = player_image
        self.image.set_colorkey('black')

        self.rect = self.image.get_rect()
        self.rect.y = y
        self.rect.x = x
        self.collected_coins = 0
        self.alive = True

    def changespeed(self, x, y):
        self.change_x += x
        self.change_y += y

    def move(self, walls, coins, enemy):

        # Move left/right
        self.rect.x += self.change_x

        # Did this update cause us to hit a wall?
        block_hit_list = pygame.sprite.spritecollide(self, walls, False)
        for block in block_hit_list:
            # If we are moving right, set our right side to the left side of
            # the item we hit
            if self.change_x > 0:
                self.rect.right = block.rect.left
            else:
                # Otherwise if we are moving left, do the opposite.
                self.rect.left = block.rect.right

        # Move up/down
        self.rect.y += self.change_y

        # Check and see if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, walls, False)
        for block in block_hit_list:

            # Reset our position based on the top/bottom of the object.
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            else:
                self.rect.top = block.rect.bottom

        coins_hit_list = pygame.sprite.spritecollide(self, coins, False)
        for coin in coins_hit_list:
            self.collected_coins += 1
            coin.kill()

        if pygame.sprite.spritecollide(self, enemy, False):
            self.alive = False


class Room(object):

    wall_list = None
    enemy_list = None
    coins_list = None
    all_sprite_list = None

    def __init__(self):
        self.wall_list = pygame.sprite.Group()
        self.enemy_list = pygame.sprite.Group()
        self.coins_list = pygame.sprite.Group()
        self.all_sprite_list = pygame.sprite.Group()


class Room1(Room):
    def __init__(self):
        super().__init__()
        walls = [[0, 0, 20, 250, WHITE],
                 [0, 350, 20, 250, WHITE],
                 [780, 0, 20, 250, WHITE],
                 [780, 350, 20, 250, WHITE],
                 [20, 0, 760, 20, WHITE],
                 [20, 580, 760, 20, WHITE],
                 [390, 50, 20, 500, BLUE]
                 ]

        for item in walls:
            wall = Wall(item[0], item[1], item[2], item[3], item[4])
            self.wall_list.add(wall)

        coins_coord = [[100, 140], [236, 50], [450, 234], [650, 400], [40, 400], [150, 450], [738, 555]]

        for coord in coins_coord:
            coin = Coin(coord[0], coord[1])
            self.coins_list.add(coin)
            self.all_sprite_list.add(coin)

        enemies_coord = [[20, 500], [410, 30]]

        for coord in enemies_coord:
            enemy = Enemy(coord[0], coord[1])
            self.enemy_list.add(enemy)
            self.all_sprite_list.add(enemy)


class Room2(Room):
    def __init__(self):
        super().__init__()

        walls = [[0, 0, 20, 250, RED],
                 [0, 350, 20, 250, RED],
                 [780, 0, 20, 250, RED],
                 [780, 350, 20, 250, RED],
                 [20, 0, 760, 20, RED],
                 [20, 580, 760, 20, RED],
                 [300, 50, 20, 500, GREEN],
                 [590, 50, 20, 500, GREEN]
                 ]

        for item in walls:
            wall = Wall(item[0], item[1], item[2], item[3], item[4])
            self.wall_list.add(wall)

        coins_coord = [[100, 140], [236, 50], [400, 234]]

        for coord in coins_coord:
            coin = Coin(coord[0], coord[1])
            self.coins_list.add(coin)

        enemies_coord = [[20, 500], [300, 50]]

        for coord in enemies_coord:
            enemy = Enemy(coord[0], coord[1])
            self.enemy_list.add(enemy)
            self.all_sprite_list.add(enemy)


class Room3(Room):
    def __init__(self):
        super().__init__()

        walls = [[0, 0, 20, 250, PURPLE],
                 [0, 350, 20, 250, PURPLE],
                 [780, 0, 20, 250, PURPLE],
                 [780, 350, 20, 250, PURPLE],
                 [20, 0, 760, 20, PURPLE],
                 [20, 580, 760, 20, PURPLE]
                 ]

        for item in walls:
            wall = Wall(item[0], item[1], item[2], item[3], item[4])
            self.wall_list.add(wall)

        for x in range(100, 800, 100):
            for y in range(50, 451, 300):
                wall = Wall(x, y, 20, 200, RED)
                self.wall_list.add(wall)

        for x in range(150, 700, 100):
            wall = Wall(x, 200, 20, 200, WHITE)
            self.wall_list.add(wall)

        coins_coord = [[100, 140], [236, 50], [400, 234]]

        for coord in coins_coord:
            coin = Coin(coord[0], coord[1])
            self.coins_list.add(coin)

        enemies_coord = [[10, 500], [400, 50]]

        for coord in enemies_coord:
            enemy = Enemy(coord[0], coord[1])
            self.enemy_list.add(enemy)
            self.all_sprite_list.add(enemy)


def main():
    pygame.display.set_caption('Maze Runner')
    player = Player(50, 50)
    movingsprites = pygame.sprite.Group()
    movingsprites.add(player)
    rooms = []
    room = Room1()
    rooms.append(room)
    room = Room2()
    rooms.append(room)
    room = Room3()
    rooms.append(room)
    current_room_no = 0
    current_room = rooms[current_room_no]
    clock = pygame.time.Clock()
    done = False
    while not done:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    player.changespeed(-5, 0)
                if event.key == pygame.K_RIGHT:
                    player.changespeed(5, 0)
                if event.key == pygame.K_UP:
                    player.changespeed(0, -5)
                if event.key == pygame.K_DOWN:
                    player.changespeed(0, 5)

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT:
                    player.changespeed(5, 0)
                if event.key == pygame.K_RIGHT:
                    player.changespeed(-5, 0)
                if event.key == pygame.K_UP:
                    player.changespeed(0, 5)
                if event.key == pygame.K_DOWN:
                    player.changespeed(0, -5)

        player.move(current_room.wall_list, current_room.coins_list, current_room.enemy_list)

        if player.rect.x < -15:
            if current_room_no == 0:
                current_room_no = 2
                current_room = rooms[current_room_no]
                player.rect.x = 790
            elif current_room_no == 2:
                current_room_no = 1
                current_room = rooms[current_room_no]
                player.rect.x = 790
            else:
                current_room_no = 0
                current_room = rooms[current_room_no]
                player.rect.x = 790

        if player.rect.x > 801:
            if current_room_no == 0:
                current_room_no = 1
                current_room = rooms[current_room_no]
                player.rect.x = 0
            elif current_room_no == 1:
                current_room_no = 2
                current_room = rooms[current_room_no]
                player.rect.x = 0
            else:
                current_room_no = 0
                current_room = rooms[current_room_no]
                player.rect.x = 0

        screen.fill(BLACK)
        if player.alive:
            movingsprites.update()
            current_room.wall_list.update()
            current_room.coins_list.update()
            current_room.enemy_list.update()
            movingsprites.draw(screen)
            current_room.wall_list.draw(screen)
            current_room.coins_list.draw(screen)
            current_room.enemy_list.draw(screen)

        else:
            player.kill()

        pygame.display.flip()

        clock.tick(60)

    pygame.quit()


if __name__ == "__main__":
    main()
